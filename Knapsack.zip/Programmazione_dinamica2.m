clear; clc;

% Load data from Excel [must be in the same directory as this executive]
ks = readmatrix("Knapsack.xlsx");

% Assing data to vectors [from 2nd and 3rd column, read till the end]
w = ks(:, 2); 
p = ks(:, 3); 
B = 1000;     
n = length(w); % Number of items

% Dynamic programming table initialization
z = zeros(B + 1, n + 1);

% Executing the iterative algorithm [could be refactorized to a function]
for i = 1:n
    for k = 0:B
        if k < w(i)
            % If capacity k is less than weight w_i, exclude item i
            z(k + 1, i + 1) = z(k + 1, i);
        else
            % If k >= w_i, choose max between excluding and including item i
            z(k + 1, i + 1) = max(z(k + 1, i), p(i) + z(k - w(i) + 1, i));
        end
    end
end

% Knapsack optimum value
cash = z(B + 1, n + 1);

% Reconstruct the solution
selected_items = zeros(1, n); % Binary vector for items (0 or 1)
remaining_capacity = B;
for i = n:-1:1
    if z(remaining_capacity + 1, i + 1) ~= z(remaining_capacity + 1, i)
        selected_items(i) = 1; % Item i included
        remaining_capacity = remaining_capacity - w(i);
    end
end

% Display the results
disp("Selected Items:");
disp(selected_items);
disp("Knapsack value:");
disp(cash);